function preload() {
  song = loadSound("music/01.mp3");
}

document.addEventListener("touchstart", function (e) {
  document.documentElement.style.overflow = "hidden";
});

document.addEventListener("touchend", function (e) {
  document.documentElement.style.overflow = "auto";
});

var HOST = window.location.origin;
var socket;
let xmlHttpRequest = new XMLHttpRequest();
let song;
let fft;
let particles = [];

class ChatMessage {
  constructor(textMessage) {
    this.textMessage = textMessage + "";
  }
}

let MAX_NUM_MESSAGES = 20;
let allMessages = new Array();
let font;
let bottomSectionHeight;
let bottomSectionY;
let sendButton;

function setup() {
  background(0);
  createCanvas(800, 800);
  setupMqtt();
  font = loadFont("assets/Swansea-q3pd.ttf");
  textFont(font);
  textSize(25);
  angleMode(DEGREES);
  fft = new p5.FFT();
  fft.setInput(song);
  song.loop();
}

function draw() {
  background(0);

  push();
  for (var i = 0; i < allMessages.length; i++) {
    var index = allMessages.length - 1 - i;
    var msg = allMessages[index];
    fill(230);
    textAlign(CENTER, CENTER);
    text(msg.textMessage, windowWidth / 2, windowHeight / 2 + i * 30);
  }
  pop();

  ////////////////////////////////////////////////////////////////////////////////

  push();
  stroke(255);
  noFill();
  translate(width / 2, height / 2);
  let wave = fft.waveform();

  for (let t = -1; t <= 1; t += 2) {
    beginShape();
    for (let i = 0; i <= 180; i += 0.5) {
      let index = floor(map(i, 0, 180, 0, wave.length - 1));

      let r = map(wave[index], -1, 1, 150, 350);

      let x = r * sin(i) * t;
      let y = r * cos(i);
      vertex(x, y);
    }
    endShape();
  }
  let p = new Particle();
  particles.push(p);

  for (let i = 0; i < particles.length; i++) {
    particles[i].update();
    particles[i].show();
  }
  pop();
}

function addNewMessage(newMessage) {
  console.log("ADDING NE MSG");
  allMessages.push(newMessage);
  if (allMessages.length >= MAX_NUM_MESSAGES) {
    allMessages.shift();
  }
}

function setupMqtt() {
  socket = io.connect(HOST);
  socket.on("mqttMessage", receiveMqtt);
}

function receiveMqtt(data) {
  var topic = data[0];
  var message = data[1];
  console.log("Topic: " + topic + ", message: " + message);
  var newMessage = new ChatMessage(message, true);
  addNewMessage(newMessage);
}

class Particle {
  constructor() {
    this.pos = p5.Vector.random2D().mult(250);
    this.vel = createVector(0, 0);
    this.acc = this.pos.copy().mult(random(0.0001, 0.00001));

    this.w = random(3, 5);
  }
  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
  }
  show() {
    noStroke();
    fill(255);
    ellipse(this.pos.x, this.pos.y, this.w);
  }
}
